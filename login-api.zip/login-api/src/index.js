// src/index.js
const express = require('express');
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Sample user database (You should replace this with a real database)
const users = [
    {
        username : "akram",
        password : "$2a$12$R23AhY.6Ov/8.br3.fL5auTPbzf5j6lVdxPO785Mhz1.vnn.iMO2u"
    }, {
        username : "naseef",
        password : "123"
    }
];

// Middleware to parse JSON bodies
app.use(express.json());
app.use(bodyParser.json());
app.use(express.urlencoded({extended:true}))
app.use(bodyParser.urlencoded({extended:true}))
// Login endpoint

console.log(users);
app.post('/login', (req, res) => {
    
    const { username, password } = req.body;
    
    // Find user by username
    const user = users.find(u => u.username === username);
    console.log(user);
    if (!user) {
        return res.status(404).json({ message: 'User not Akram found' });
    }

    // Compare passwords
    bcrypt.compare(password, user.password, (err, result) => {
        if (err || !result) {
            return res.status(401).json({ message: 'Invalid password' });
        }
        res.json({ message: 'Login successful' });
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
